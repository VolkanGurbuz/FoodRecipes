package com.example.foodrecipes.util;

public class Constants {

  public static final String BASE_URL = "https://www.food2fork.com/";
  public static final String API_KEY = "5261eada0a051f797c3610ab88800e43";
}
